from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.properties import ObjectProperty
from kivy.lang import Builder
from kivy.uix.popup import Popup
from kivy.uix.floatlayout import FloatLayout
import pandas as pd

class Test(MDApp):
    def build(self):
        self.title = 'Retina images'
        self.theme_cls.primary_palette = "Blue"
        return Builder.load_string(
            '''
BoxLayout:
    orientation:'vertical'
    MDToolbar:
        title: 'Retina images'
        md_bg_color: app.theme_cls.primary_color
        specific_text_color: 1, 1, 1, 1

    MDBottomNavigation:
                
        MDBottomNavigationItem:
            name: 'screen 1'
            text: 'stage1'
            icon: 'retina'

            Image:
                id: imageView
                source: 'python.png'
        
        MDBottomNavigationItem:
            name: 'screen 2'
            text: 'greyscale'
            icon: 'retina'

            Image:
                id: imageView
                source: 'cp.png'

        MDBottomNavigationItem:
            name: 'screen 3'
            text: 'enhancedimage'
            icon: 'retina'

            Image:
                id: imageView
                source: 'kivy.png'
        
               
'''
        )


Test().run()